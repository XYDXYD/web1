$(document).ready(function() {
  var mouseXcord_old = 0; //where was the selected span
  var mouseYcord_old = 0;
  var activespan = ''; //which is the selected span
  var whichspan = 0; //if the span moved in #htmlbox-droparea which is the elem what we hit
  var testA, testAthis, testAreaLeftX, testAreaTopY, testAreaRightX, testAreaBottomY; //The values of #htmlbox-droparea

  init(); //start initialize, rebuild span elements and add startDrag function

  function startDrag(e) { //when mousedown is active on span
    testAreaLeftX = testA.offset().left; //Recalculate values of #htmlbox-droparea
    testAreaTopY = testA.offset().top;
    testAreaRightX = testAreaLeftX + testAthis.offsetWidth;
    testAreaBottomY = testAreaTopY + testAthis.offsetHeight;

    whichspan = 0;
    activespan = $(this);
    activespan.css('cursor', 'move');
    $('#htmlbox-buttons-manager span.'+ activespan.attr('class')).bind('mouseup', addToBox);
    activespan.unbind('mouseup', removeFromBox);
    mouseXcord_old = e.pageX;
    mouseYcord_old = e.pageY;
    $(document).mousemove(performDrag); //Add performDrag function to each elements

    // Whether the selected span is in #htmlbox-droparea or in #htmlbox-buttons-manager add endDrag2 or endDrag
    if ($(this).parent().is('#htmlbox-droparea')) {
      $(document).bind('mouseup', endDrag2);
      activespan.bind('mouseup', removeFromBox).unbind('mouseup', addToBox);
    }
    else {
      $(document).bind('mouseup', endDrag);
    }
    return false;
  }
  
  /**
   * Handle drag. Mouse is moving and button is down, watch for changes
   */
  function performDrag(e) {
    activespan.css({ //moving of activespan
        left: (e.pageX-mouseXcord_old) +'px',
        top: (e.pageY-mouseYcord_old) +'px'
      }).unbind('mouseup', addToBox).unbind('mouseup', removeFromBox);

    // Whether span is in #htmlbox-droparea or not
    if (e.pageX < testAreaRightX && e.pageX > testAreaLeftX &&
      e.pageY < testAreaBottomY && e.pageY > testAreaTopY) {
      var distance;
      var leftOrRight;
      whichspan = 0;

      $('.helper', testA).remove();
      $('span', testA).each(function(){//determine which is the activespan
        if (activespan.css('left') != $(this).css('left') ) {
          var marginTopBottom = (parseInt($(this).css('margin-left'), 10) +
            parseInt($(this).css('margin-right'), 10)) / 2;
          var spanLeftX = $(this).offset().left;
          var spanTopY = $(this).offset().top - marginTopBottom;
          var spanRightX = spanLeftX + this.offsetWidth;
          var spanBottomY = spanTopY + this.offsetHeight+(marginTopBottom * 2);
          var spanMiddlePoint = spanLeftX+this.offsetWidth / 2;

          if (e.pageY < spanBottomY && e.pageY > spanTopY ) {
            if (distance > Math.abs(spanMiddlePoint-e.pageX) || distance == undefined) {
              leftOrRight = spanMiddlePoint - e.pageX;
              distance = Math.abs(leftOrRight);
              whichspan = $(this);
            }
          }
        }
      });


      // Drawing of helper, helper is an empty span which help to determine where the selected span will be placed
      var helper = '<span class="helper" style="height: '+
        (parseInt(activespan.css('height'), 10) - 2) +'px; padding-left: '+
        activespan.css('padding-left') +'; padding-right: '+
        activespan.css('padding-right') +';"></span>';

      // Add helper to the left or right side of whichspan
      if (whichspan) {
        if (leftOrRight<0) {
          whichspan.after(helper);
          whichspan.poz = 'after';
        }
        else {
          whichspan.before(helper);
        }
      }
      else testA.append(helper);
    }
    else {
      $('.helper', testA).remove();
    }

    return false;
  }

  /**
   * Handle drag finishing on selected span dragged from #htmlbox-buttons-manager
   */
  function endDrag(e) {
    $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag);
    activespan.css('cursor', '');
    backanimate(e);
    updateOptions();
  }
  
  /**
   * Handle drag finishing on selected span dragged from #htmlbox-droparea
   */
  function endDrag2(e) {
    $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag2);
    activespan.css('cursor', '');
    backanimate2(e);
    updateOptions();
  }

  /**
   * Adds the activespan to the #htmlbox-droparea
   */
  function addToBox() {
    $('.helper', testA).remove();
    // Separator elements can be added to #htmlbox-droparea multiple times,
    // so only hide the rest.
    if (!activespan.is('.htmlbox-separator_basic') && !activespan.is('.htmlbox-separator_dots')) {
      activespan.css({cursor: ''}).hide();
    }
    $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag);

    var clonespan = activespan.clone().css('display', 'block').bind('mousedown', startDrag);

    // The activespan will be added to left or right side of whichspan
    if (whichspan) {
      if (whichspan.poz == 'after') {
        whichspan.after(clonespan);
      }
      else {
        whichspan.before(clonespan);
      }
    }
    else {
      testA.append(clonespan);
    }
  }
  
  /**
   * Remove the selected span from #htmlbox-droparea
   */
  function removeFromBox() {
    activespan.remove();
    $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag2);
    $('#htmlbox-buttons-manager span.'+ activespan.attr('class')).show().bind('mousedown', startDrag);
  }
  
  /**
   * Update the button order in the hidden textarea based on the items dropped into the box
   */
  function updateOptions() {
    var options = [];
    testA.find('span[@class]').each(function () {
      options.push($(this).attr('class').replace(/^htmlbox-/, ''));
    }).end();
    $('#edit-htmlbox-buttons-order').val(options.join(', '));
  }


  /**
   * Move the selected span from #htmlbox-buttons-manager back to start
   * position or add to #htmlbox-droparea.
   */
  function backanimate(e) {
    activespan.css({left: '', top: ''});
    if (e.pageX < testAreaRightX && e.pageX > testAreaLeftX && e.pageY < testAreaBottomY && e.pageY > testAreaTopY ) {
      addToBox();
    }
    else {
      activespan.bind('mouseup', addToBox);
    }
  }

  /**
   * Remove the selected span from #htmlbox-buttons-manager or
   * move it to new position.
   */
  function backanimate2(e) {
    $('.helper', testA).remove();

    // If the activespan is outside of the #htmlbox-droparea remove it, or move it to new order position
    if (e.pageX > testAreaRightX || e.pageX < testAreaLeftX || e.pageY > testAreaBottomY || e.pageY < testAreaTopY ) {
      activespan.remove();
      $('#htmlbox-buttons-manager span.'+ activespan.attr('class')).css('display', 'block').bind('mousedown', startDrag);
    }
    else {
      var clonespan = $('#htmlbox-buttons-manager span.'+ activespan.attr('class')).clone(false).css('display', 'block').unbind('mouseup', addToBox).bind('mousedown', startDrag);

      if (whichspan) {
        if (whichspan.poz == 'after') {
          whichspan.after(clonespan);
        }
        else {
          whichspan.before(clonespan);
        }
      }
      else {
        testA.append(clonespan);
      }
      activespan.remove();
    }
  }

  /**
   * Initialize the working environment from what we currently have in the form,
   * and also prepare drag-and-drop.
   */
  function init() {
    $('div.htmlbox-buttons').before('<div class="htmlbox-buttons htmlbox-buttons-js"><div id="htmlbox-droparea"></div><div id="htmlbox-buttons-manager" class="clear-block"></div></div>').find('span').each(function () {
      // Move all buttons from the order field's description to #htmlbox-buttons-manager.
      $('#htmlbox-buttons-manager').append(this);
    }).end().remove();
    testA = $('#htmlbox-droparea');
    testAthis = testA[0];

    // Move the items already added to the order to the newly created box.
    $.each($('#edit-htmlbox-buttons-order').val().split(','), function(name, value) {
      value = $.trim(value)
      if (value && value.length) {
        var elem = $('#htmlbox-buttons-manager').find('span.htmlbox-'+ $.trim(value));
        // Only hide non separator items
        if (!elem.is('.htmlbox-separator_basic') && !elem.is('.htmlbox-separator_dots')) {
          elem.hide();
        }
        testA.append(elem.clone(false).show());
      }
    });
    // Hide the order field's textarea.
    window.setTimeout("$('#edit-htmlbox-buttons-order').parents('div.form-item:first').children().not('label').not('.description').hide()", 10);

    // Change the description text of the textarea.
    var textNode = $('.htmlbox-buttons').find('span').bind('mousedown', startDrag).end().get(0).previousSibling;
    if (textNode.nodeType == 3) {
      textNode.nodeValue = Drupal.settings.htmlbox.order_description;
    }
  }
});