<?php
return array(
	//'配置项'=>'配置值'

    // 添加数据库配置信息
    'DB_TYPE'   => 'mysql', // 数据库类型
    'DB_HOST'   => 'localhost', // 服务器地址
    'DB_NAME'   => 'thinkphp', // 数据库名
    'DB_USER'   => 'thinkphp', // 用户名
    'DB_PWD'    => 'DoNotThink', // 密码
    'DB_PORT'   => 3306, // 端口
    'DB_PREFIX' => 'think_', // 数据库表前缀
    //'DB_DSN' => 'mysql://root@localhost:3306/thinkphp'是更简洁的写法
);
?>
