<?php
define('APP_DEBUG', TRUE);
require './ThinkPHP/ThinkPHP.php';
