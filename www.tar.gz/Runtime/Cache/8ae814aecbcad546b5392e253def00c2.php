<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" href="__ROOT__/Common/kindeditor/themes/default/default.css" />
		<link rel="stylesheet" href="__ROOT__/Common/style/edit.css" />
	    <script charset="utf-8" src="__ROOT__/Common/jquery/jquery-1.9.1.min.js"></script>
	    <script charset="utf-8" src="__ROOT__/Common/kindeditor/kindeditor-min.js"></script>
	    <script charset="utf-8" src="__ROOT__/Common/kindeditor/lang/zh_CN.js"></script>
	    <script>
	        $(function(){
	            var editor = KindEditor.create('textarea[name="content"]',{
		            uploadJson : '__URL__/uploadFile',
		            fileManagerJson : '__URL__/manageFile',
		            allowFileManager : true});
		    });
	    </script>
	</head>
	<body>
        <form method="post" action="__URL__/update">
            <input type="hidden" name="a_id" value="<?php echo ($article["a_id"]); ?>">
            标题:<input type="text" name="title" value="<?php echo ($article["title"]); ?>"><br/>
            作者:<input type="text" name="author" value="<?php echo ($article["author"]); ?>"><br/>
            日期:<input type="text" name="date" value="<?php echo ($article["date"]); ?>"><br/>
		    <textarea name="content"><?php echo ($article["content"]); ?></textarea></br>
            <input type="submit" value="确定">
        </form>
    </body>
</html>