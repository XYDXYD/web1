<?php
class IndexAction extends Action {
    public function index(){
	echo 'welcome';
    }
}
